from pathlib import Path
import base64,re
root=Path(__file__).resolve().parents[1];d=root/'dist'
css=(d/'style.css').read_text()+'\n'+(d/'studio.css').read_text()
for name in re.findall(r'url\((assets/[^)]+)\)',css):
 data=base64.b64encode((d/name).read_bytes()).decode();css=css.replace('url('+name+')','url(data:font/ttf;base64,'+data+')')
js=(root/'build/app.bundle.js').read_text().replace('</script','<\\/script')

js=re.sub(r'<a href="assets/sports-centre.mp4" download>.*?</a>','',js)
for asset,mime in [('sports-centre.mp4','video/mp4'),('sports-centre.jpg','image/jpeg')]:
 if (d/'assets'/asset).exists():
  js=js.replace('assets/'+asset,'data:'+mime+';base64,'+base64.b64encode((d/'assets'/asset).read_bytes()).decode())
h=(d/'index.html').read_text();h=h.replace('src="assets/ssla-95.svg"','src="data:image/svg+xml;base64,'+base64.b64encode((d/'assets/ssla-95.svg').read_bytes()).decode()+'"');h=re.sub(r'<link rel="preload"[^>]+>','',h);h=h.replace('<link rel="stylesheet" href="studio.css">','');h=h.replace('<link rel="stylesheet" href="style.css">','<style>'+css+'</style>').replace('<script type="module" src="app.js"></script>','<script>'+js+'</script>').replace('<body data-theme="light">','<body data-theme="light" data-offline="true">')
(d/'downloads/CIVILIST_OFFLINE.html').write_text(h)
print('Offline bytes',len(h.encode()))
